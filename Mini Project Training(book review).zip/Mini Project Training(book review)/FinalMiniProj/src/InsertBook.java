

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class InsertBook
 */
@WebServlet("/InsertBook")
public class InsertBook extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public InsertBook() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		try
		{
			String bookId=request.getParameter("bookid");
			String bookName=request.getParameter("bookname");
			String bookAuthor=request.getParameter("bookauthor");
			
			Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb","root","root");
			PreparedStatement pst=con.prepareStatement("insert into bookdetail values(?,?,?)");
			pst.setString(1,bookId);
			pst.setString(2,bookName);
			pst.setString(3,bookAuthor);
			
			int i=pst.executeUpdate();
			if(i>0)
			{
				HttpSession se=request.getSession();
				se.setAttribute("bookInsertion","Book Added successfully");
				response.sendRedirect("insertbook.jsp");
			}
		}
		catch(Exception e)
		{
			PrintWriter out=response.getWriter();
			out.println(e);
		}
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
