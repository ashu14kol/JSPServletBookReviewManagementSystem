import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/UserAuthenticate")
public class UserAuthenticate extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public UserAuthenticate() {	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		PrintWriter out=response.getWriter();
		try 
		{

			HttpSession session=request.getSession();

			String userId=request.getParameter("userid");
			String password=request.getParameter("password");


			Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb","root","root");

			PreparedStatement pst1=con.prepareStatement("select * from userdetails where uid='"+userId+"'");
			ResultSet resultset=pst1.executeQuery();
			String dbPassword = null;
			if(resultset.next())      
			{

				dbPassword = resultset.getString(3);
				String passwordDec = AESencrp.decrypt(dbPassword);
				if (passwordDec.equals(password))
				{
					session.setAttribute("userid",resultset.getString(1));
					session.setAttribute("username",resultset.getString(2));	
					try{
						String userid =(String)session.getAttribute("userid");
						Date userlogin_time=new Date(session.getCreationTime());

						File file =new File("D:\\Group2\\FinalMiniProj\\log.txt");

						//if file doesnt exists, then create it
						if(!file.exists()){
							file.createNewFile();
						}
						
						PrintWriter pw=new PrintWriter(new FileWriter(file,true));
						pw.write("  UserId :  "+userid + "  Last Logon time: " +userlogin_time + " \n");
						pw.flush();
						pw.close();

						System.out.println("Done");

					}catch(IOException e){
						e.printStackTrace();
					}

					RequestDispatcher requestdispatcher=request.getRequestDispatcher("userhome.jsp");
					requestdispatcher.forward(request, response);
				}
				else
				{
					session.setAttribute("umessage","Username/Password is invalid");
					RequestDispatcher requestDispatcher=request.getRequestDispatcher("userlogin.jsp");
					requestDispatcher.forward(request, response);
				}
			}
			else
			{

				session.setAttribute("umessage","User is not registered");
				RequestDispatcher requestDispatcher=request.getRequestDispatcher("userlogin.jsp");
				requestDispatcher.forward(request, response);
			}

		}



		catch(Exception e)
		{
			out.println(e);
		}
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}


}
