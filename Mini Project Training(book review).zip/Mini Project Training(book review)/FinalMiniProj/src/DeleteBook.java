

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class DeleteBook
 */
@WebServlet("/DeleteBook")
public class DeleteBook extends HttpServlet {
	private static final long serialVersionUID = 1L;


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		try
		{

			String bookId=request.getParameter("bookid");
			Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb","root","root");
			PreparedStatement pst1=con.prepareStatement("delete from bookreview where bid=?");
			pst1.setString(1,bookId);
			int i=pst1.executeUpdate();
			PreparedStatement pst=con.prepareStatement("delete from bookdetail where bid=?");
			pst.setString(1,bookId);
			int j=pst.executeUpdate();
			if(i>=0&&j>0)
			{
				HttpSession se=request.getSession();
				se.setAttribute("bookDelete",bookId);
				response.sendRedirect("deletebook.jsp");
			}
		}
		catch(Exception e)
		{
			PrintWriter out=response.getWriter();
			out.println(e);
		}
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
